import 'package:flutter/material.dart';

Color bluedefault() => const Color.fromRGBO(77, 119, 255, 1);
Color greydefault() => const Color.fromRGBO(102, 102, 102, 1);
const kDefaultDuration = Duration(milliseconds: 250);
