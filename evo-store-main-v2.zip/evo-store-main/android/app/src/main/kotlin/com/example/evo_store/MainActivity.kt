package com.example.evo_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
